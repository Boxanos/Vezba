/**
 * 
 */
/**
 * @author ThinkPad
 *
 */
module Vakcine {
	requires java.sql;
}