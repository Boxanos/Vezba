package vakcine.DAO;

import vakcine.model.Prijava;



public interface PrijavaDAO {

	
	public void add(Prijava prijava) throws Exception;


	
}
